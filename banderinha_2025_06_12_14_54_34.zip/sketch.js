let bandeirinhas = []; // Array para armazenar as bandeirinhas
let pontuacao = 0;
let tempoRestante = 30; // 30 segundos de jogo
let gameStarted = false;
let gameEnded = false;

// Variáveis para o anzol (ou mira)
let anzolX;
let anzolY;
let anzolLargura = 20;
let anzolAltura = 50;

function setup() {
  createCanvas(800, 600);
  // Posição inicial do anzol
  anzolX = width / 2;
  anzolY = height - 100;

  // Cria algumas bandeirinhas iniciais
  for (let i = 0; i < 10; i++) {
    bandeirinhas.push(new Bandeirinha());
  }

  // Configura um timer para o jogo
  setInterval(contarTempo, 1000); // Chama a função contarTempo a cada 1 segundo
}

function draw() {
  background(100, 150, 255); // Céu azul

  // Desenhar o chão/arraial
  fill(139, 69, 19); // Marrom
  rect(0, height - 80, width, 80);

  // Desenhar balões (exemplo)
  desenharBalao(100, 100, color(255, 0, 0));
  desenharBalao(600, 50, color(0, 255, 0));

  // Desenhar e mover as bandeirinhas
  for (let i = 0; i < bandeirinhas.length; i++) {
    let b = bandeirinhas[i];
    b.mover();
    b.desenhar();
  }

  // Desenhar o anzol (ou mira)
  fill(0);
  rect(anzolX, anzolY, anzolLargura, anzolAltura); // Haste do anzol
  // Aqui você pode adicionar um formato de anzol mais elaborado ou uma mira

  // Mostrar placar
  fill(255);
  textSize(24);
  text("Pontuação: " + pontuacao, 10, 30);

  // Mostrar tempo restante
  text("Tempo: " + tempoRestante, width - 120, 30);

  if (gameEnded) {
    fill(255, 0, 0);
    textSize(48);
    textAlign(CENTER, CENTER);
    text("FIM DE JOGO!", width / 2, height / 2);
    textSize(32);
    text("Sua pontuação: " + pontuacao, width / 2, height / 2 + 50);
  } else if (!gameStarted) {
    fill(0, 0, 0, 150);
    rect(0, 0, width, height);
    fill(255);
    textSize(36);
    textAlign(CENTER, CENTER);
    text("Clique para Iniciar!", width / 2, height / 2);
    textSize(24);
    text("Mova o mouse para mover o anzol e clique para pescar!", width / 2, height / 2 + 50);
  }
}

function mouseMoved() {
  if (gameStarted) {
    anzolX = mouseX - anzolLargura / 2; // Centraliza o anzol no mouse
  }
}

function mousePressed() {
  if (!gameStarted) {
    gameStarted = true;
  } else if (!gameEnded) {
    // Lógica para "pescar"
    for (let i = bandeirinhas.length - 1; i >= 0; i--) {
      let b = bandeirinhas[i];
      // Verifica se o clique está dentro da área da bandeirinha e se o anzol está próximo
      if (dist(mouseX, mouseY, b.x, b.y) < b.tamanho / 2 + 10 &&
          dist(anzolX + anzolLargura / 2, anzolY, b.x, b.y) < 50) { // Verifica a proximidade do anzol
        pontuacao += b.pontos;
        bandeirinhas.splice(i, 1); // Remove a bandeirinha pescada
        // Adiciona uma nova bandeirinha para manter o jogo rolando
        bandeirinhas.push(new Bandeirinha());
        break; // Pescamos apenas uma bandeirinha por clique
      }
    }
  }
}

function contarTempo() {
  if (gameStarted && !gameEnded) {
    tempoRestante--;
    if (tempoRestante <= 0) {
      gameEnded = true;
    }
  }
}

// Classe Bandeirinha
class Bandeirinha {
  constructor() {
    this.x = random(width);
    this.y = random(-200, -50); // Começa acima da tela
    this.velocidade = random(1, 3);
    this.tamanho = random(30, 60);
    this.cor = color(random(255), random(255), random(255)); // Cores aleatórias
    this.pontos = floor(map(this.tamanho, 30, 60, 10, 50)); // Bandeirinhas menores valem mais
  }

  mover() {
    this.y += this.velocidade;
    if (this.y > height + this.tamanho) { // Se sair da tela, reseta
      this.y = random(-200, -50);
      this.x = random(width);
    }
  }

  desenhar() {
    fill(this.cor);
    noStroke();
    // Desenha o formato básico de uma bandeirinha (um triângulo ou um quadrado com ponta)
    triangle(this.x, this.y, this.x + this.tamanho, this.y, this.x + this.tamanho / 2, this.y + this.tamanho);
    // Ou: rect(this.x, this.y, this.tamanho, this.tamanho * 0.7); // Para um quadrado
  }
}

// Função para desenhar um balão
function desenharBalao(x, y, c) {
  fill(c);
  noStroke();
  ellipse(x, y, 60, 80); // Corpo do balão
  triangle(x - 15, y + 40, x + 15, y + 40, x, y + 60); // Parte de baixo
  stroke(0);
  line(x, y + 60, x, y + 90); // Corda
}